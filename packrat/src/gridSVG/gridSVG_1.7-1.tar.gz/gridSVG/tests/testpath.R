
library(grid)
require(gridSVG)

example(grid.path)

grid.export("path.svg")
