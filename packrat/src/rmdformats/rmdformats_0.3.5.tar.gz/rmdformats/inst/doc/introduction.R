## ----eval=FALSE----------------------------------------------------------
#  ---
#  title: "My document"
#  date: "`r Sys.Date()`"
#  author: John Doe
#  output:
#    rmdformats::readthedown:
#      self_contained: true
#      thumbnails: true
#      lightbox: true
#      gallery: false
#      highlight: tango
#  ---

