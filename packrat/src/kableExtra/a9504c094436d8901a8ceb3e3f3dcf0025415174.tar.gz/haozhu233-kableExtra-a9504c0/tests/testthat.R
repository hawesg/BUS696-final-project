library(testthat)
library(kableExtra)

test_check("kableExtra")
