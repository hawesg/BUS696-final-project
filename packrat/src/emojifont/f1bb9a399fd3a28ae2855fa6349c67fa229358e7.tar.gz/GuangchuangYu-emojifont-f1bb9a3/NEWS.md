# emojifont 0.5.3

+ update docs, now `phylomoji` is documented on <https://yulab-smu.github.io/treedata-book/chapter8.html#phylomoji>.

# emojifont 0.5.2

+ mv `phylomoji` vignette
  to <https://guangchuangyu.github.io/software/ggtree/vignettes/phylomoji.html>
  (2018-05-23, Wed)
