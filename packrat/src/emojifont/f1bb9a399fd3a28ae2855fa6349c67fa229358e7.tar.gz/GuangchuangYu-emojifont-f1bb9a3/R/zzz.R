.onAttach <- function(libname, pkgname) {
    load.emojifont()
    ## load.emojifont("OpenSansEmoji")
    load.fontawesome()
}
