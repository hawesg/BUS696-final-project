<meta http-equiv="refresh" content="0; url=https://guangchuangyu.github.io/2016/03/font-awesome-supported-in-emojifont" />
