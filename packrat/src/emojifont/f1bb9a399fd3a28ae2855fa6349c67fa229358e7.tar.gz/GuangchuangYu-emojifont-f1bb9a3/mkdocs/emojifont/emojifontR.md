<meta http-equiv="refresh" content="0; url=https://guangchuangyu.github.io/2015/12/use-emoji-font-in-r" />
