<!-- AddToAny BEGIN -->
<div class="a2a_kit a2a_kit_size_32 a2a_default_style">
<a class="a2a_dd" href="//www.addtoany.com/share"></a>
<a class="a2a_button_facebook"></a>
<a class="a2a_button_twitter"></a>
<a class="a2a_button_google_plus"></a>
<a class="a2a_button_pinterest"></a>
<a class="a2a_button_reddit"></a>
<a class="a2a_button_sina_weibo"></a>
<a class="a2a_button_wechat"></a>
<a class="a2a_button_douban"></a>
</div>
<script async src="//static.addtoany.com/menu/page.js"></script>
<!-- AddToAny END -->

<link rel="stylesheet" href="https://guangchuangyu.github.io/css/font-awesome.min.css">

## <i class="fa fa-twitter"></i> Tweets

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Distribution of Chinese zodiac signs at the family holiday party. <a href="https://t.co/oSMyX4dome">https://t.co/oSMyX4dome</a> <a href="https://twitter.com/guangchuangyu">@guangchuangyu</a> <a href="https://t.co/Ac6V1kuRjZ">pic.twitter.com/Ac6V1kuRjZ</a></p>&mdash; Joseph Stachelek (@jjstache) <a href="https://twitter.com/jjstache/status/813459335930056704">December 26, 2016</a></blockquote>

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr"><a href="https://twitter.com/drob">@drob</a> <a href="https://twitter.com/timelyportfolio">@timelyportfolio</a> back in March I celebrated my PhD thesis submission with gganimate <a href="https://t.co/OVNDgTC2i4">pic.twitter.com/OVNDgTC2i4</a></p>&mdash; Maëlle Salmon (@ma_salmon) <a href="https://twitter.com/ma_salmon/status/799729775979806720">November 18, 2016</a></blockquote>


<blockquote class="twitter-tweet" data-lang="en"><p lang="ja" dir="ltr">16/04/25 公開<br>Rでお遊び：絵文字をプロット「emojifont」パッケージ <a href="https://t.co/D2ClyMQMxX">https://t.co/D2ClyMQMxX</a></p>&mdash; からだにいいもの (@KaradaGood) <a href="https://twitter.com/KaradaGood/status/724342323157454848">April 24, 2016</a></blockquote>

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">how about using emoji to label host species in phylogenetic tree? <a href="https://twitter.com/hashtag/rstats?src=hash">#rstats</a> <a href="https://twitter.com/hashtag/visualization?src=hash">#visualization</a> <a href="https://twitter.com/hashtag/ggtree?src=hash">#ggtree</a> <a href="https://twitter.com/hashtag/emojifont?src=hash">#emojifont</a> <a href="https://t.co/MRKQvNNAUh">pic.twitter.com/MRKQvNNAUh</a></p>&mdash; Guangchuang Yu (@guangchuangyu) <a href="https://twitter.com/guangchuangyu/status/708160510441566211">March 11, 2016</a></blockquote>

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr"><a href="https://twitter.com/drob">@drob</a> and <a href="https://twitter.com/guangchuangyu">@guangchuangyu</a>, this is data surfing (air quality data from Lima, Peru) / fun with your cool pkgs. Thx! <a href="https://t.co/ikinjxDDZL">pic.twitter.com/ikinjxDDZL</a></p>&mdash; Maëlle Salmon (@ma_salmon) <a href="https://twitter.com/ma_salmon/status/706490090609106944">March 6, 2016</a></blockquote>

<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">easy to produce embed subplot using subview function, <a href="http://t.co/pF5qslthcj">http://t.co/pF5qslthcj</a> <a href="https://twitter.com/hashtag/ggtree?src=hash">#ggtree</a> <a href="https://twitter.com/hashtag/rstats?src=hash">#rstats</a> <a href="https://twitter.com/hashtag/ggplot2?src=hash">#ggplot2</a> <a href="http://t.co/jMnB0NeS5Z">pic.twitter.com/jMnB0NeS5Z</a></p>&mdash; Guangchuang Yu (@guangchuangyu) <a href="https://twitter.com/guangchuangyu/status/638734888187752448">September 1, 2015</a></blockquote>

<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>


## <i class="fa fa-wordpress"></i> Blog posts

+ <http://www.masalmon.eu/2017/01/27/catan/>

![](https://github.com/masalmon/masalmon.github.io/blob/master/public/catan.gif?raw=true)

+ <https://guangchuangyu.github.io/2016/03/font-awesome-supported-in-emojifont/>

![](http://guangchuangyu.github.io/blog_images/2016/douban_emoji.jpg)

![](https://raw.githubusercontent.com/GuangchuangYu/emojifont/master/vignettes/figures/fontawesome.png)

+ <https://www.karada-good.net/analyticsr/r-484/>

![](https://www.karada-good.net/wp/wp-content/uploads/2016/04/baseemoji-320x314.png)


