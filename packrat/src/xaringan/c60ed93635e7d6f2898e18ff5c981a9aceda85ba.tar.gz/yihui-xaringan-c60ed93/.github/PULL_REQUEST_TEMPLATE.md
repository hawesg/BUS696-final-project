To contribute to this repo, please make sure to:

- [ ] Sign the CLA http://www.clahub.com/agreements/yihui/xaringan (if you haven't signed it before).
- [ ] Add a news item to NEWS.md and your name to DESCRIPTION (by alphabetical order) unless you have already been listed there.
- [ ] Provide a URL to a live example (and even better, a couple of screenshots) if you are contributing a new theme.

Thank you!
