#' Helper functions
#'
#' A collection of handy, helper functions
#'
#' @import ggplot2
#' @docType package
#' @name useful
#' @aliases useful-package useful
NULL
