library(testthat)
library(useful)

test_check("useful")
