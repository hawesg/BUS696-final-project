## Test environments
* local OS X install, R 3.3.2
* win-builder 
* Travis

## R CMD check results
There were no ERRORs, WARNINGs or NOTEs. 

## Downstream dependencies
I have also run R CMD check on downstream dependencies of ggpubr. 
All packages that I could install passed.


## Update

This is an update version 0.2.4 (see NEWS.md).

