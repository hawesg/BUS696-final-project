library(testthat)
library(xaringanthemer)

test_check("xaringanthemer")
