#' @importFrom grDevices col2rgb rgb rgb2hsv hsv
#' @keywords internal
"_PACKAGE"
