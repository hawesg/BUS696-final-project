#' @title Monotone Dark Theme
#' @description A dark monotone theme based around a single color.
