#' @title Write A Customized Xaringan Theme
#' @description Creates a customized Xaringan theme CSS file.
