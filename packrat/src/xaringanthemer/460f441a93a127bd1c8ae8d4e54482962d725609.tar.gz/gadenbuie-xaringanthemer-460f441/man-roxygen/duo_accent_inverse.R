#' @title Duotone Accent Inverse Theme
#' @description An "inverted" default xaringan theme with a two colors used
#'   for color accents on select elements (headers, bold text, etc.).
