#' @title Monotone Light Theme
#' @description A light monotone theme based around a single color.
