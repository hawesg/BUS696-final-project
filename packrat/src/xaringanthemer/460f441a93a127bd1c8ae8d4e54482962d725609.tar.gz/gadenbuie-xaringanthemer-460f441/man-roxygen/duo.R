#' @title Duotone Theme
#' @description A duotone theme designed to work well with two complementary
#'   colors.
