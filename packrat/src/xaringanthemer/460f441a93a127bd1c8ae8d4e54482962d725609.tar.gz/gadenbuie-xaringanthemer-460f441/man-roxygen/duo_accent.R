#' @title Duotone Accent Theme
#' @description An default xaringan theme with a two colors used for color
#'   accents on select elements (headers, bold text, etc.).
