#' @title Monotone Accent Theme
#' @description The default xaringan theme with a single color used for color
#'   accents on select elements (headers, bold text, etc.).
