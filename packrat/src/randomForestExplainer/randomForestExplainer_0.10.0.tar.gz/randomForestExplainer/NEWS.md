# randomForestExplainer 0.10.0
## New features
* Added support for ranger forests.
* Added support for unsupervised randomForest.
* Added tests for most functions.

## Bug fixes
* Fixed bug for explain_forest not finding templates.
* Added more intuitive error message for explain_forest when local importance is absent.
