library(testthat)
library(randomForestExplainer)

test_check("randomForestExplainer")
