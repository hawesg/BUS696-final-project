
library(testthat)

test_check("commentr")

