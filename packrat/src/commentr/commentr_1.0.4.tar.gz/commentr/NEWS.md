# commentr 1.0.3

* Package moved to Bitbucket to conform with other cancercentrum packages
* test updated to conform with new version of testthat



