<p><img src="https://raw.githubusercontent.com/trinker/sentimentr/master/inst/sentimentr_logo/r_sentimentr.png" width="300"/><br/>
<p><a href="http://trinker.github.com/sentimentr_dev">sentimentr</a> is a...</p>
<p>Download the development version of sentimentr <a href="https://github.com/trinker/sentimentr/">here</a>
