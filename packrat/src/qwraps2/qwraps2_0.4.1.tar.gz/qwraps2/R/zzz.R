.onUnload <- function(libpath) {
  library.dynam.unload("qwraps2", libpath)
}
