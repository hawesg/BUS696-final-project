library(testthat)
library(qwraps2)

test_check("qwraps2")
