#' @title [Defunct!] Pairwise sign tests with matrix output
#' @description Defunct. Performs pairwise sign tests.
#' @param ... Anything.
#' @return NULL
#' @export
pairwiseSignMatrix <- function(...) {
  .Defunct(
    msg = "'pairwiseSignMatrix' is defunct.\nUse PMCMR or PMCMRplus packages.")
}