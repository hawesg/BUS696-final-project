#' @title [Defunct!] Pairwise two-sample robust tests with matrix output
#' @description Defunct. Performs pairwise two-sample robust tests across groups
#'              with matrix output.
#' @param ... Anything.
#' @return NULL
#' @export
pairwiseRobustMatrix <- function(...) {
  .Defunct(
    msg = "'pairwiseRobustMatrix' is defunct.")
}