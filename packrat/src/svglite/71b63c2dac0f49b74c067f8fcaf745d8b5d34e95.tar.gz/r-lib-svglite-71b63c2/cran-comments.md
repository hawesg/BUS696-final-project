
Should fix the CRAN failure when UTF-8 is not available.

## Test environments

* local OS X install, R release
* ubuntu 12.04 (on travis-ci), R release
* win-builder (devel and release)


## R CMD check results

0 errors | 0 warnings | 0 note


## Downstream dependencies

* I ran R CMD check on all 18 downstream dependencies (summary at
  https://github.com/r-lib/svglite/blob/master/revdep/readme.md).
  No problems were found.
