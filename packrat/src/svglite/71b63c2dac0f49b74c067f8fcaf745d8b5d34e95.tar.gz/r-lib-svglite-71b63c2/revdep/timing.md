# Check times

|   |package    |version | check_time|
|:--|:----------|:-------|----------:|
|3  |mlr        |2.9     |      936.4|
|2  |ggplot2    |2.1.0   |      532.2|
|1  |DeLorean   |1.2.4   |      471.3|
|4  |rsvg       |1.0     |       52.2|
|5  |svgPanZoom |0.3.3   |       30.3|


