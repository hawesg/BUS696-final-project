library(testthat)
library(svglite)

test_check("svglite")
