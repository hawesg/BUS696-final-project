`eigenvals.pcr` <- function(x, ...) {
    x$varExpl
}
