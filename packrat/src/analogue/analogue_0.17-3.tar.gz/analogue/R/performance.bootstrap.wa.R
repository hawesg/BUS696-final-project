`performance.bootstrap.wa` <- function(object, ...) {
    performance.predict.wa(object)
}
