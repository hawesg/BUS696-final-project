library(testthat)
library(slidex)

test_check("slidex")
