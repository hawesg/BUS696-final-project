#' Demo dataset with Words and Frequency
#'
#' A data file of words and frequency from tm package
#'
#' @format A data set with 1011 observations of 2 variables, words and frequancy
#'
"demoFreq"


#' Demo dataset with Chinese character Words and Frequency
#'
#' A data file of words and frequency from tm package
#'
#' @format A data set with 885 observations of 2 variables, words and frequancy
#'
"demoFreqC"
