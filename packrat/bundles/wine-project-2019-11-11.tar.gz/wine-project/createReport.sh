#!/bin/bash

# Run the R script to run the analysis.
rscript "main.R"
