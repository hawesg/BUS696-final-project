### Probably irrelevant because we are looking to model
#seq(0, 3000, by = 25)
# stats <-
#   wine_data %>% group_by(pr = cut(
#     price,
#     breaks = c(0, 10, 25, 50, 100, 200, 500, 1000, 3500),
#     dig.lab = 5
#   )) %>% summarize(
#     count = n(),
#     min = min(points),
#     max = max(points),
#     avg = mean(points),
#     sd = sd(points)
#   )
# stats
# 
# 

